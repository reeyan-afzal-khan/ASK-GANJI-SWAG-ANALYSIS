#!/usr/bin/env python3
"""Evaluate transcribed speech against MANUALLY VERIFIED Roman Urdu + English references.

Gold CSV: episode,start,end,reference. Reference MUST be literal words heard in audio.
WER is a spelling-sensitive proxy and is NOT model confidence.
"""
import argparse, csv, json
from pathlib import Path
from roman_asr.core import write_csv, episode_id
from roman_asr.quality import error_rates


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--references',type=Path,required=True)
    ap.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'run_output')
    args=ap.parse_args(argv)
    with args.references.open(newline='',encoding='utf-8-sig') as f:
        gold=list(csv.DictReader(f))
    result=[]; weighted_errors=0; word_total=0
    for sample in gold:
        ref=sample.get('reference','').strip()
        if not ref:continue
        eid=episode_id(sample['episode'])
        path=args.output/'transcripts'/f'{eid}.json'
        if not path.exists():
            print('No transcript for',eid,'(skipping)');continue
        obj=json.loads(path.read_text(encoding='utf-8'))
        a,b=float(sample['start']),float(sample['end'])
        text=' '.join(s['text'] for s in obj['segments'] if a<=(s['start']+s['end'])/2 < b)
        metrics=error_rates(ref,text)
        if not metrics:continue
        weighted_errors+=metrics['wer']*metrics['reference_words']
        word_total+=metrics['reference_words']
        result.append({'episode':eid,'start':a,'end':b,'reference':ref,
                       'hypothesis':text,'wer':round(metrics['wer'],4),
                       'cer':round(metrics['cer'],4),'reference_words':metrics['reference_words']})
    out=args.output/'evaluation.csv'
    write_csv(out,result,['episode','start','end','reference','hypothesis','wer','cer','reference_words'])
    print(f'Scored {len(result)} human-annotated clips. Weighted WER: {weighted_errors/word_total:.3%}' if word_total else 'No manually populated references to score.')
    print('Open',out)
if __name__=='__main__':main()
