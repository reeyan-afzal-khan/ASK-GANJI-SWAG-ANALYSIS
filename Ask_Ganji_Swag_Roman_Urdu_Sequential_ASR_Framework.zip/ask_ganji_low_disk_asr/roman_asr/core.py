"""Storage, episode selection, CSV manifests and lossless subtitles."""
import csv
import json
import os
import re
import tempfile
from pathlib import Path
from urllib.parse import parse_qs, urlparse

EP_RE = re.compile(r'episode[_\s-]?(\d{1,3})', re.I)
HEAD_RE = re.compile(r'<summary>\s*<strong>\s*Episode\s+(\d{1,3})\s*</strong>\s*</summary>', re.I)
LINK_RE = re.compile(r'https?://(?:www\.)?(?:youtube\.com/watch\?[^)\s]+|youtu\.be/[\w-]{11}[^)\s]*)')


def episode_num(value):
    m = EP_RE.search(str(value))
    return int(m.group(1)) if m else int(value)


def episode_id(value):
    return f'episode_{episode_num(value):03d}'


def select_episodes(spec, available):
    available = sorted(set(int(n) for n in available))
    if spec.strip().lower() == 'all':
        return available
    requested = set()
    for item in spec.split(','):
        item = item.strip()
        if not item:
            continue
        if '-' in item and re.fullmatch(r'\d+\s*-\s*\d+', item):
            a, b = [int(x) for x in item.split('-')]
            if a > b:
                raise ValueError(f'Invalid descending range {item}')
            requested.update(range(a, b + 1))
        else:
            requested.add(episode_num(item))
    missing = requested - set(available)
    if missing:
        raise ValueError(f'Episodes not in manifest: {sorted(missing)}')
    return sorted(requested)


def video_id_from_url(url):
    parsed = urlparse(url.replace('&amp;', '&'))
    if parsed.hostname in ('youtu.be', 'www.youtu.be'):
        return parsed.path.strip('/').split('/')[0]
    if parsed.hostname in ('youtube.com', 'www.youtube.com', 'm.youtube.com'):
        return parse_qs(parsed.query).get('v', [''])[0]
    return ''


def parse_video_manifest(markdown):
    result = {}
    ep = None
    for line in markdown.splitlines():
        match = HEAD_RE.search(line)
        if match:
            ep = int(match.group(1))
        if ep is None:
            continue
        for link in LINK_RE.findall(line):
            vid = video_id_from_url(link)
            if re.fullmatch(r'[A-Za-z0-9_-]{11}', vid):
                if ep in result and result[ep] != vid:
                    raise ValueError(f'Multiple YouTube video IDs for episode {ep}: {result[ep]}, {vid}')
                result[ep] = vid
    return result


def read_manifest(path):
    with open(path, newline='', encoding='utf-8-sig') as f:
        rows = list(csv.DictReader(f))
    out = {}
    for row in rows:
        n = episode_num(row.get('episode', ''))
        if n in out:
            raise ValueError(f'Duplicate manifest episode: {n}')
        vid = row.get('video_id', '').strip()
        if not re.fullmatch(r'[A-Za-z0-9_-]{11}', vid):
            raise ValueError(f'Invalid video ID for episode {n}: {vid}')
        row['episode'] = episode_id(n)
        out[n] = row
    return out


def write_csv(path, rows, fields):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix=path.name, suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
            writer.writeheader()
            writer.writerows(rows)
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.remove(temp)


def write_text_atomic(path, content):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix=path.name, suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(content)
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.remove(temp)


def load_segments(path):
    content = json.loads(Path(path).read_text(encoding='utf-8'))
    return content['segments'], content.get('metadata', {})


def fmt_srt_time(seconds):
    ms = max(0, round(float(seconds) * 1000))
    hours, ms = divmod(ms, 3_600_000)
    minutes, ms = divmod(ms, 60_000)
    secs, ms = divmod(ms, 1000)
    return f'{hours:02d}:{minutes:02d}:{secs:02d},{ms:03d}'


def srt_format(segments):
    blocks = []
    for seg in segments:
        text = re.sub(r'\s+', ' ', str(seg['text'])).strip()
        a, b = float(seg['start']), float(seg['end'])
        if text and b > a:
            blocks.append(f'{len(blocks)+1}\n{fmt_srt_time(a)} --> {fmt_srt_time(b)}\n{text}\n')
    return '\n'.join(blocks) + ('\n' if blocks else '')


def parse_srt(text):
    # Strictly parse timestamps but tolerate UTF8 BOM and multiple text lines.
    pattern = re.compile(r'(?m)^(\d+)\s*\n(\d\d:\d\d:\d\d[,.]\d\d\d)\s*-->\s*(\d\d:\d\d:\d\d[,.]\d\d\d)\s*\n')
    matches = list(pattern.finditer(text.lstrip('\ufeff').replace('\r\n', '\n')))
    clean = text.lstrip('\ufeff').replace('\r\n', '\n')
    def sec(t):
        hh, mm, other = t.replace(',', '.').split(':')
        return int(hh) * 3600 + int(mm) * 60 + float(other)
    segments = []
    for i, m in enumerate(matches):
        raw = clean[m.end(): matches[i + 1].start() if i + 1 < len(matches) else None].strip()
        if raw:
            segments.append({'start': sec(m.group(2)), 'end': sec(m.group(3)), 'text': re.sub(r'\s+', ' ', raw)})
    return segments
