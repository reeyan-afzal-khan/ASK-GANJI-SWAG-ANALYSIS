"""Explicit optional romanization of Urdu-script model outputs.

Mechanical uroman is not native Roman Urdu. Ollama can change speech content;
ALWAYS retain source text and flag changed outputs for human review.
"""
import json
import hashlib
from pathlib import Path
import re
import urllib.request
from functools import lru_cache

URDU = re.compile(r'[\u0600-\u06FF]')

@lru_cache(maxsize=1)
def _uroman_engine():
    from uroman import Uroman
    return Uroman()


def romanize(text, method='none', ollama_model='qwen3:1.7b', endpoint='http://127.0.0.1:11434'):
    if method == 'none' or not URDU.search(text):
        return text
    if method == 'uroman':
        # Romanize only Urdu-script stretches; never rewrite an English code-switched term.
        arabic_stretches = re.compile(r'[\u0600-\u06FF]+(?:\s+[\u0600-\u06FF]+)*')
        return arabic_stretches.sub(lambda match: _uroman_engine().romanize_string(match.group(0), lcode='urd'), text)
    if method == 'ollama':
        prompt = (
            'Convert only Urdu-script portions of the text into natural Pakistani Roman Urdu. '
            'DO NOT translate or paraphrase. Do not remove fillers or repeated words. '
            'Preserve English terms, names, punctuation and numerals exactly. '
            'Return ONLY a single-line Latin-script transcript with no comments. '
            'Example: آج ہم machine learning پر بات کریں گے۔ => Aaj hum machine learning par baat karenge.\n'
            f'Text: {text}'
        )
        payload = {'model': ollama_model, 'prompt': prompt, 'stream': False,
                   'options': {'temperature': 0.0}, 'think': False}
        req = urllib.request.Request(endpoint.rstrip('/') + '/api/generate',
                                     data=json.dumps(payload).encode(),
                                     headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=150) as resp:
            result = json.load(resp)
        output = re.sub(r'\s+', ' ', result.get('response', '')).strip()
        if not output:
            raise RuntimeError('Ollama returned empty romanization')
        # Treat overly divergent outputs as failed conversion, never silently substitute.
        if len(output) > max(200, len(text) * 3.5):
            raise RuntimeError('Ollama romanization too long; possible hallucination')
        return output
    raise ValueError(f'Unknown romanization mode: {method}')


def romanize_segments(segments, method='none', ollama_model='qwen3:1.7b', cache_dir=None):
    output = []
    for s in segments:
        c = dict(s)
        source = c['text']
        cache_path = None
        if cache_dir and method != 'none' and URDU.search(source):
            key = hashlib.sha256((method + '\0' + ollama_model + '\0' + source).encode('utf-8')).hexdigest()
            cache_path = Path(cache_dir) / (key + '.json')
        if cache_path and cache_path.exists():
            converted = json.loads(cache_path.read_text(encoding='utf-8'))['converted']
        else:
            converted = romanize(source, method=method, ollama_model=ollama_model)
            if cache_path:
                from .core import write_text_atomic
                write_text_atomic(cache_path, json.dumps({'source': source, 'converted': converted},
                                                        ensure_ascii=False) + '\n')
        if converted != source:
            c['asr_original_text'] = source
            c['text'] = converted
            c['romanization_method'] = method
            c['requires_romanization_review'] = True
        output.append(c)
    return output
