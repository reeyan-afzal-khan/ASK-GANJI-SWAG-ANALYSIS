"""Audio acquisition/conversion and VAD chunking (16 kHz mono FLAC)."""
from pathlib import Path
import shutil
import subprocess


def run(args):
    print('+', ' '.join(str(a) for a in args), flush=True)
    subprocess.run([str(a) for a in args], check=True)


def require_binary(binary):
    if shutil.which(binary) is None:
        raise RuntimeError(f'{binary} not found on PATH. Install it before continuing.')


def transcode(src, dest):
    require_binary('ffmpeg')
    src, dest = Path(src), Path(dest)
    if src.resolve() == dest.resolve():
        return dest
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.stem + '.part.flac')
    try:
        run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-i', src,
             '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'flac', tmp])
        tmp.replace(dest)
    finally:
        tmp.unlink(missing_ok=True)
    return dest


def download_episode(video_id, episode, workspace, overwrite=False):
    require_binary('yt-dlp')
    raw_dir = Path(workspace) / 'raw_audio'
    raw_dir.mkdir(parents=True, exist_ok=True)
    dest = Path(workspace) / 'audio' / f'{episode}.flac'
    if dest.exists() and not overwrite:
        return dest
    # Download a single ID, independent of playlist order (playlist can change).
    template = str(raw_dir / f'{episode}.%(ext)s')
    cmd = ['yt-dlp', '--no-playlist', '--format', 'bestaudio/best',
           '--no-mtime', '--output', template,
           'https://www.youtube.com/watch?v=' + video_id]
    if not overwrite:
        cmd.append('--no-overwrites')
    run(cmd)
    candidates = [p for p in raw_dir.glob(f'{episode}.*') if p.is_file() and not p.name.endswith(('.part', '.ytdl', '.json'))]
    if not candidates:
        raise RuntimeError(f'No audio file downloaded for {episode}')
    # In rare cases old formats may coexist; newest file wins.
    return transcode(max(candidates, key=lambda p: p.stat().st_mtime), dest)


def extract_audio_clip(src, dest, start, end):
    require_binary('ffmpeg')
    if end <= start:
        raise ValueError('Invalid clip time range')
    Path(dest).parent.mkdir(parents=True, exist_ok=True)
    run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
         '-ss', f'{start:.3f}', '-i', src, '-t', f'{end-start:.3f}',
         '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'flac', dest])


def speech_windows(wave, use_vad=True, max_duration=24.0, max_gap=0.55):
    """Return speech-containing windows, preserving absolute times, no concatenation.

    Silero boundaries are approximate and can miss weak speech; optional disable-VAD
    is provided for difficult recordings.
    """
    duration = len(wave) / 16000.0
    if duration <= 0:
        return []
    if use_vad:
        import torch
        from silero_vad import load_silero_vad, get_speech_timestamps
        model = load_silero_vad()
        spans = get_speech_timestamps(torch.from_numpy(wave.copy()), model,
                                      sampling_rate=16000, return_seconds=True,
                                      speech_pad_ms=300, min_silence_duration_ms=350)
        spans = [(max(0., float(p['start'])), min(duration, float(p['end']))) for p in spans]
    else:
        spans = [(0.0, duration)]
    result = []
    start = end = None
    for s, e in spans:
        if e <= s:
            continue
        if start is not None and e - start <= max_duration and s - end <= max_gap:
            end = e
        else:
            if start is not None:
                result.extend(split_long(start, end, max_duration))
            start, end = s, e
    if start is not None:
        result.extend(split_long(start, end, max_duration))
    return result


def split_long(start, end, max_duration):
    out = []
    while start < end - 0.01:
        cut = min(end, start + max_duration)
        out.append((round(start, 3), round(cut, 3)))
        start = cut
    return out
