"""Create readable captions without inventing word-level timing accuracy.

When the ASR's word sequence exactly matches the output text, use estimated ASR
word timestamps.  When text was romanized, its words may no longer align, so
all subcue timing is explicitly marked as proportional/approximate.
"""
import re


def normalized_words(text):
    return re.findall(r"\S+", re.sub(r"\s+", " ", text).strip())


def subdivide_segment(seg, max_chars=76, max_secs=5.5, max_gap=0.9):
    text = str(seg.get('text', '')).strip()
    a, b = float(seg['start']), float(seg['end'])
    if not text or b <= a:
        return []
    words = normalized_words(text)
    anchors = seg.get('words') or []
    valid_word_timing = (
        len(anchors) == len(words)
        and all(float(w['end']) > float(w['start']) for w in anchors)
        and ' '.join(normalized_words(' '.join(w['text'] for w in anchors))) == ' '.join(words)
        and not seg.get('requires_romanization_review')
    )
    if valid_word_timing:
        timed = [(min(b, max(a, float(w['start']))), min(b, max(a, float(w['end']))), word)
                 for w, word in zip(anchors, words)]
        if any(e <= s for s, e, _ in timed):
            valid_word_timing = False
    if not valid_word_timing:
        # Weight each token by character length, rather than claiming exact alignment.
        weights = [max(1, len(w)) for w in words]
        total = sum(weights)
        cur = a
        timed = []
        for i, (word, weight) in enumerate(zip(words, weights)):
            nxt = b if i == len(words)-1 else a + (b-a) * sum(weights[:i+1])/total
            timed.append((cur, nxt, word))
            cur = nxt
    groups, cur_group = [], []
    for s, e, w in timed:
        new_text = ' '.join([it[2] for it in cur_group] + [w])
        too_long = cur_group and (len(new_text) > max_chars or e - cur_group[0][0] > max_secs
                                  or s - cur_group[-1][1] > max_gap)
        if too_long:
            groups.append(cur_group)
            cur_group = []
        cur_group.append((s, e, w))
    if cur_group:
        groups.append(cur_group)
    out = []
    for g in groups:
        cue = {'start': round(g[0][0], 3), 'end': round(g[-1][1], 3),
               'text': ' '.join(it[2] for it in g),
               'timing_method': 'whisper_word_alignment' if valid_word_timing else 'approximate_proportional'}
        if cue['end'] > cue['start']:
            out.append(cue)
    return out


def captionize(segments, max_chars=76, max_secs=5.5):
    out = []
    for seg in segments:
        out.extend(subdivide_segment(seg, max_chars=max_chars, max_secs=max_secs))
    # Prevent accidental overlap due to imperfect word alignment.
    last_end = 0.0
    for item in out:
        if item['start'] < last_end:
            item['start'] = round(last_end, 3)
        if item['end'] <= item['start']:
            item['end'] = round(item['start'] + .001, 3)
        last_end = item['end']
    return out
