"""Heuristic safety flags, segment comparison and ground-truth edit metrics."""
import re
import unicodedata
from difflib import SequenceMatcher

ARABIC = re.compile(r'[\u0600-\u06FF]')
NON_LATIN = re.compile(r'[^\x00-\x7F]')
WORD = re.compile(r"[a-z0-9]+(?:'[a-z]+)?", re.I)


def normalize(text, variants=None):
    # Keep only Latin words and digits in WER; this is valid for Roman Urdu only.
    t = unicodedata.normalize('NFKC', text).lower().replace('’', "'")
    words = WORD.findall(t)
    if variants:
        words = [variants.get(w, w) for w in words]
    return words


def edit_distance(a, b):
    # Levenshtein distance, linear memory; not a normalized confidence measure.
    previous = list(range(len(b) + 1))
    for i, x in enumerate(a, 1):
        cur = [i]
        for j, y in enumerate(b, 1):
            cur.append(min(cur[-1] + 1, previous[j] + 1, previous[j - 1] + (x != y)))
        previous = cur
    return previous[-1]


def error_rates(reference, hypothesis, variants=None):
    ref, hyp = normalize(reference, variants), normalize(hypothesis, variants)
    if not ref:
        return None
    wer = edit_distance(ref, hyp) / len(ref)
    rchars, hchars = ''.join(ref), ''.join(hyp)
    cer = edit_distance(rchars, hchars) / max(1, len(rchars))
    return {'wer': wer, 'cer': cer, 'reference_words': len(ref), 'hyp_words': len(hyp)}


def flags_for_segments(segments):
    findings = []
    prev_norm = ''
    streak = 0
    for i, s in enumerate(segments):
        t = s.get('text', '').strip()
        norm = re.sub(r'[^\w]+', '', t.lower())
        if len(norm) >= 15 and norm == prev_norm:
            streak += 1
        else:
            streak = 1
        prev_norm = norm
        duration = max(.001, s['end'] - s['start'])
        reasons = []
        if ARABIC.search(t):
            reasons.append('urdu_script_not_roman')
        if duration > 12:
            reasons.append('subtitle_duration_gt_12s')
        if len(t) / duration > 27 and len(t) > 30:
            reasons.append('fast_text_density')
        if len(t) <= 8 and duration > 8:
            reasons.append('very_short_text_in_long_segment')
        if streak >= 3:
            reasons.append('consecutive_duplicate_text')
        if s.get('compression_ratio') is not None and s['compression_ratio'] > 2.4:
            reasons.append('high_compression_ratio')
        if s.get('avg_logprob') is not None and s['avg_logprob'] < -1.0:
            reasons.append('low_avg_logprob')
        if s.get('requires_romanization_review'):
            reasons.append('romanization_needs_review')
        if s.get('timing_method') == 'approximate_proportional':
            reasons.append('approximate_timing')
        if reasons:
            findings.append({'segment': i + 1, 'start': round(s['start'], 3),
                             'end': round(s['end'], 3), 'reasons': ';'.join(reasons),
                             'text': t})
    return findings


def compare_by_windows(segments_a, segments_b, duration, size=30, threshold=.60):
    """Compare two ASR outputs; disagreement is a review flag, not a correctness judgment."""
    rows = []
    start = 0.
    while start < duration:
        end = min(duration, start + size)
        def collect(segments):
            return ' '.join(s['text'] for s in segments if
                            (s['start'] + s['end']) / 2 >= start and
                            (s['start'] + s['end']) / 2 < end)
        a, b = collect(segments_a), collect(segments_b)
        left, right = ' '.join(normalize(a)), ' '.join(normalize(b))
        # Comparisons between Arabic-script and Roman-script require first romanizing;
        # otherwise the similarity will be artificially poor.
        mixed_scripts = bool(ARABIC.search(a)) != bool(ARABIC.search(b))
        ratio = SequenceMatcher(None, left, right, autojunk=False).ratio() if left or right else 1.0
        if ratio < threshold or mixed_scripts:
            rows.append({'start': round(start, 3), 'end': round(end, 3),
                         'agreement_similarity': round(ratio, 3),
                         'script_mismatch': mixed_scripts,
                         'model_a_text': a, 'model_b_text': b})
        start = end
    return rows
