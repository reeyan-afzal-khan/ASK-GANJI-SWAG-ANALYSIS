"""Small local helpers for the sequential Roman Urdu transcription pipeline."""
