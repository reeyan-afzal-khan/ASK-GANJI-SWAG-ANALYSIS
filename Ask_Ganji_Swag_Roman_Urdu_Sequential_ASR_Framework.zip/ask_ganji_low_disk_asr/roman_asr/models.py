"""Whisper Turbo and Roman-Urdu fine-tuned Whisper Small backends."""
import re
from pathlib import Path

# A prompt is a bias, NOT an instruction Whisper reliably follows. Measure actual script output.
ROMAN_PROMPT = (
    'Transcription in Roman Urdu mixed with English. '
    'Aaj hum aap ke sawalat discuss karenge. '
    'Mera khayal hai ke education, career, relationship aur business important hain. '
    'Machine learning, technology, university, immigration, skills, job interview.'
)


def split_caption(start, end, text, max_chars=78, max_secs=5.8):
    """For text-only output, create explicitly APPROXIMATE caption timings.

    This is NOT word alignment. Durations are allocated by character weights;
    each generated subtitle must be reviewed against audio before publication.
    """
    tokens = text.split()
    if not tokens or end <= start:
        return []
    groups, acc = [], []
    char_limit = max(28, min(max_chars, int(max_chars * max_secs / max(0.1, end - start)) if end - start > max_secs else max_chars))
    for w in tokens:
        if acc and len(' '.join(acc + [w])) > char_limit:
            groups.append(' '.join(acc))
            acc = []
        acc.append(w)
    if acc:
        groups.append(' '.join(acc))
    # Ensure long, quickly spoken chunks are subdivided to a manageable duration.
    while len(groups) < int((end - start) / max_secs + 0.999) and any(len(g.split()) > 1 for g in groups):
        j = max(range(len(groups)), key=lambda k: len(groups[k]))
        words = groups.pop(j).split()
        mid = max(1, len(words) // 2)
        groups[j:j] = [' '.join(words[:mid]), ' '.join(words[mid:])]
    weights = [max(1, len(g)) for g in groups]
    total = sum(weights)
    cur = float(start)
    out = []
    for i, (g, wt) in enumerate(zip(groups, weights)):
        nxt = float(end) if i == len(groups) - 1 else cur + (end - start) * wt / total
        out.append({'start': round(cur, 3), 'end': round(nxt, 3), 'text': g,
                    'timing_method': 'approximate_proportional', 'avg_logprob': None,
                    'compression_ratio': None, 'no_speech_prob': None})
        cur = nxt
    return out


class Turbo:
    def __init__(self, model='large-v3-turbo', device='auto', compute='auto', roman_prompt=False, language='ur'):
        from faster_whisper import WhisperModel
        self.model_id = model
        self.model = WhisperModel(model, device=device, compute_type=compute)
        self.language = None if language == 'auto' else language
        self.roman_prompt = roman_prompt

    def transcribe(self, audio_path, use_vad=True):
        segments, info = self.model.transcribe(
            str(audio_path), task='transcribe', language=self.language,
            beam_size=5, vad_filter=use_vad,
            condition_on_previous_text=False, word_timestamps=True,
            hallucination_silence_threshold=2.0,
            initial_prompt=ROMAN_PROMPT if self.roman_prompt else None,
            temperature=[0.0, 0.2, 0.4, 0.6],
        )
        out = []
        for seg in segments:
            out.append({
                'start': round(float(seg.start), 3),
                'end': round(float(seg.end), 3),
                'text': seg.text.strip(),
                'avg_logprob': float(seg.avg_logprob),
                'compression_ratio': float(seg.compression_ratio),
                'no_speech_prob': float(seg.no_speech_prob),
                'timing_method': 'whisper_word_alignment',
                'words': [{'start': round(float(w.start), 3), 'end': round(float(w.end), 3),
                           'text': w.word, 'probability': w.probability} for w in (seg.words or [])]
            })
        return out, {'language': info.language, 'model_id': self.model_id,
                     'timestamp_note': 'Whisper estimated word-level alignment; review for drift.'}


class RomanSmall:
    model_id = 'cheetos18/whisper-small-roman-urdu'

    def __init__(self, device='auto', max_chunk_secs=24.0):
        import torch
        from transformers import WhisperProcessor, WhisperForConditionalGeneration
        self.torch = torch
        self.device = ('cuda' if torch.cuda.is_available() else 'cpu') if device == 'auto' else device
        if self.device not in ('cpu', 'cuda'):
            raise ValueError('Roman-small backend currently supports cpu/cuda only')
        self.processor = WhisperProcessor.from_pretrained(self.model_id)
        self.model = WhisperForConditionalGeneration.from_pretrained(self.model_id).to(self.device)
        self.model.eval()
        self.max_chunk_secs = max_chunk_secs

    def transcribe(self, audio_path, use_vad=True):
        import numpy as np
        import soundfile as sf
        from .audio import speech_windows
        wave, sr = sf.read(str(audio_path), dtype='float32')
        if sr != 16000 or wave.ndim != 1:
            raise ValueError('Roman-small requires 16kHz mono audio; run import-audio first.')
        windows = speech_windows(wave, use_vad=use_vad, max_duration=self.max_chunk_secs)
        results = []
        for i, (start, end) in enumerate(windows, 1):
            data = wave[max(0, int(start * 16000)): min(len(wave), int(end * 16000))]
            inputs = self.processor(data, sampling_rate=16000, return_tensors='pt')
            with self.torch.inference_mode():
                ids = self.model.generate(inputs.input_features.to(self.device),
                                          max_new_tokens=225, num_beams=3,
                                          do_sample=False, task='transcribe')
            text = self.processor.batch_decode(ids, skip_special_tokens=True)[0].strip()
            # Exact VAD time boundaries, but words assigned to seconds heuristically.
            results.extend(split_caption(start, end, text))
            if i % 20 == 0:
                print(f'    Roman-small: {i}/{len(windows)} chunks', flush=True)
        return results, {'language': 'ur/en (unverified)', 'model_id': self.model_id,
                         'timestamp_note': 'Speech window boundaries from Silero; subtitle timings are approximate proportional, NOT aligned.'}


def make_backend(name, device='auto', compute='auto', language='ur'):
    if name == 'roman-small':
        return RomanSmall(device=device)
    if name == 'turbo-roman-prompt':
        return Turbo(device=device, compute=compute, roman_prompt=True, language=language)
    if name == 'turbo-urdu':
        return Turbo(device=device, compute=compute, roman_prompt=False, language=language)
    raise ValueError(f'Unknown model {name}')
