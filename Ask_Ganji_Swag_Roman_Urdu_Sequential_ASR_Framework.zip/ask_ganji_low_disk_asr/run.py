#!/usr/bin/env python3
"""Low-disk sequential ASR: download ONE episode -> WAV -> ASR -> SRT -> DELETE -> next.

Use a stable manifest of original video IDs, not the playlist's current sorting.
No old subtitle file is read or fed to the recognizer. Does not require GPUs for
basic operation, but CPU runs will be much slower.
"""
import argparse
import csv
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
from pathlib import Path

from roman_asr.core import read_manifest, select_episodes, episode_id, srt_format, write_csv, write_text_atomic
from roman_asr.quality import ARABIC, flags_for_segments
from roman_asr.subtitles import captionize
from roman_asr.romanize import romanize_segments

ROOT = Path(__file__).resolve().parent
DEFAULT_MANIFEST = ROOT / 'data' / 'episodes.csv'
PLAYLIST = 'https://www.youtube.com/playlist?list=PLinUrn8TVRE-hm3-CsyoQaySKYbxLtG6B'


def cli():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument('--episodes', default='all', help='all, 2, 002, 2-5, or 2,35,100')
    ap.add_argument('--manifest', type=Path, default=DEFAULT_MANIFEST)
    ap.add_argument('--output', type=Path, default=ROOT / 'run_output')
    ap.add_argument('--temp-dir', type=Path, default=None, help='Optional temp root on another drive')
    ap.add_argument('--download-mode', choices=['audio','video'], default='audio',
                    help='audio only saves disk; video downloads a <=480p muxed video first')
    ap.add_argument('--model', choices=['roman-small','turbo-roman-prompt','turbo-urdu'], default='roman-small')
    ap.add_argument('--romanizer', choices=['uroman','ollama','none'], default='uroman',
                    help='Fallback for any remaining Urdu script; uroman is mechanical, not linguistically reliable')
    ap.add_argument('--ollama-model', default='qwen3:1.7b')
    ap.add_argument('--language', choices=['ur','auto','en'], default='auto')
    ap.add_argument('--device', choices=['auto','cuda','cpu'], default='auto')
    ap.add_argument('--compute', default='auto', help='For faster-whisper: auto, float16, int8, etc')
    ap.add_argument('--no-vad', action='store_true', help='May improve quiet speech; increases silence hallucination risk')
    ap.add_argument('--force', action='store_true', help='Reprocess and replace existing completed output')
    ap.add_argument('--keep-going', action='store_true', help='Continue with other episodes after an error')
    ap.add_argument('--keep-temp', action='store_true', help='For diagnostics; NOT compatible with low-disk goal')
    ap.add_argument('--min-free-gb', type=float, default=0.5,
                    help='Abort new download if free space on temp volume is below threshold')
    ap.add_argument('--sleep', type=float, default=2.0, help='Delay between episodes')
    ap.add_argument('--cookies-from-browser', default=None,
                    help='Optional local browser cookies for videos you have rights to access')
    ap.add_argument('--js-runtime', choices=['deno','node','quickjs'], default='deno')
    ap.add_argument('--dry-run', action='store_true', help='List planned episodes; download and model not run')
    ap.add_argument('--status', action='store_true', help='Show completion status without downloading')
    return ap.parse_args()


def profile(args):
    return {
        'model': args.model, 'romanizer': args.romanizer,
        'ollama_model': args.ollama_model if args.romanizer == 'ollama' else None,
        'language': args.language, 'device': args.device, 'compute': args.compute,
        'vad': not args.no_vad, 'software_profile': 'low_disk_v1',
    }


def fingerprint(profile_dict):
    return hashlib.sha256(json.dumps(profile_dict, sort_keys=True).encode()).hexdigest()


def paths(output, eid):
    return {ext: output / sub / (eid + '.' + ext)
            for ext, sub in [('srt','srt'),('json','transcripts'),('txt','raw_asr'),('done.json','done')]}


def completed(output, eid, signature, force=False):
    p = paths(output,eid)
    if force:
        return False
    if not p['srt'].exists() and not p['done.json'].exists():
        return False
    if not p['srt'].exists() or not p['done.json'].exists():
        raise RuntimeError(f'{eid}: incomplete prior output, use --force after inspecting {p["srt"]}')
    meta = json.loads(p['done.json'].read_text(encoding='utf-8'))
    if meta.get('signature') != signature:
        raise RuntimeError(f'{eid}: prior SRT has DIFFERENT model/config. Use a separate --output or --force.')
    return True


def preflight(args):
    if shutil.which('ffmpeg') is None:
        raise RuntimeError('FFmpeg not on PATH. Install FFmpeg first.')
    if args.romanizer == 'ollama':
        print('Ollama conversion enabled. Make sure ollama serve is running and model is downloaded.', flush=True)
    if args.js_runtime == 'deno' and shutil.which('deno') is None:
        print('WARNING: Deno is not on PATH; recent YouTube downloads may fail. See README.', file=sys.stderr)


def make_download_command(video_url, target_dir, mode='audio', js_runtime='deno', cookies=None):
    # A single YouTube video URL, NEVER the full playlist URL, so downloads are sequential.
    args = [sys.executable, '-m', 'yt_dlp', '--no-playlist', '--no-progress',
            '--no-mtime', '--retries', '5', '--fragment-retries', '5',
            '--socket-timeout', '30', '--js-runtimes', js_runtime,
            '-f', 'bestaudio/best' if mode == 'audio' else 'best[height<=480]/best',
            '-o', str(target_dir / 'source.%(ext)s')]
    if cookies:
        args.extend(['--cookies-from-browser', cookies])
    args.append(video_url)
    return args


def downloaded_media(target_dir):
    allowed = {'.mp4','.m4a','.webm','.opus','.ogg','.mp3','.mkv','.mov','.aac','.flv','.ts','.wav'}
    found = [p for p in target_dir.glob('source.*') if p.is_file() and p.suffix.lower() in allowed]
    if len(found) != 1:
        raise RuntimeError(f'Expected one source media file; found {len(found)} in {target_dir}.')
    return found[0]


def check_wav_disk_space(source, directory, min_free_gb):
    """Reject conversion early if the expected PCM WAV cannot fit on disk.

    FFprobe durations can be missing/inaccurate for unusual containers, so this
    is an estimate and is not a guarantee against out-of-space conditions.
    """
    if shutil.which('ffprobe') is None:
        print('WARNING: ffprobe absent; cannot estimate WAV size before converting.', file=sys.stderr)
        return
    result = subprocess.run(['ffprobe','-v','error','-show_entries','format=duration',
                             '-of','default=noprint_wrappers=1:nokey=1', str(source)],
                            text=True, capture_output=True, check=False)
    if result.returncode != 0:
        return
    try:
        duration = float(result.stdout.strip())
    except ValueError:
        return
    if not (0 < duration < 604800):
        return
    predicted_bytes = duration * 16000 * 2 + 4*1024*1024
    free = shutil.disk_usage(directory).free
    threshold = predicted_bytes + min_free_gb * (1024 ** 3)
    if free < threshold:
        raise RuntimeError(f'Insufficient space for estimated WAV ({predicted_bytes/1e6:.0f} MB): '
                           f'{free/1e9:.2f} GB free, retaining {min_free_gb} GB reserve. '
                           'Use --temp-dir on a larger drive.')


def extract_wav(source, target):
    cmd = ['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-y','-i',str(source),
           '-map','0:a:0','-vn','-ac','1','-ar','16000','-c:a','pcm_s16le',str(target)]
    subprocess.run(cmd, check=True)
    if not target.is_file() or target.stat().st_size <= 44:
        raise RuntimeError('FFmpeg produced an empty WAV.')


def checks_for_asr(segments, cues):
    flags = flags_for_segments(segments)
    if not cues:
        raise RuntimeError('ASR returned no usable subtitle cues. Review whether audio contains speech.')
    if any(ARABIC.search(s['text']) for s in cues):
        flags.append({'segment': -1, 'start': 0, 'end': 0, 'reasons': 'NON_ROMAN_SCRIPT_OUTPUT',
                      'text': 'Output still contains Arabic/Urdu characters. Change --romanizer.'})
        # Never label remaining Urdu-script text a complete Roman-Urdu deliverable.
        raise RuntimeError('Subtitle still contains Urdu/Arabic script; use --romanizer ollama/uroman or revise model.')
    approximated = sum(c['timing_method'] == 'approximate_proportional' for c in cues)
    if approximated:
        flags.append({'segment': 0, 'start': cues[0]['start'], 'end': cues[-1]['end'],
                      'reasons': f'approximate_subtitle_timing:{approximated}_cues',
                      'text': 'Approximate timings must be checked against speech.'})
    return flags


def process_one(row, args, model, signature):
    eid = row['episode']
    out = paths(args.output, eid)
    # Ensure clean temp media is deleted after every success OR ordinary error.
    tmpbase = args.temp_dir or args.output / '_temporary_media'
    tmpbase.mkdir(parents=True, exist_ok=True)
    working = Path(tempfile.mkdtemp(prefix='asr_episode_', dir=tmpbase))
    try:
        free = shutil.disk_usage(tmpbase).free / (1024 ** 3)
        if free < args.min_free_gb:
            raise RuntimeError(f'Not enough free space on temporary drive: {free:.2f} GB; requires --min-free-gb {args.min_free_gb}.')
        video_url = row['url'].strip() or 'https://www.youtube.com/watch?v=' + row['video_id']
        print(f'[{eid}] 1/4: downloading {args.download_mode} from {video_url}', flush=True)
        subprocess.run(make_download_command(video_url, working, args.download_mode,
                        args.js_runtime, args.cookies_from_browser), check=True)
        source = downloaded_media(working)
        wav = working / 'audio_16k_mono.wav'
        print(f'[{eid}] 2/4: transcoding to WAV...', flush=True)
        check_wav_disk_space(source, working, args.min_free_gb)
        extract_wav(source, wav)
        # Remove compressed media immediately, minimizing peak disk use while ASR runs.
        source.unlink()
        print(f'[{eid}] 3/4: fresh ASR from WAV ({wav.stat().st_size/1e6:.1f} MB)', flush=True)
        raw, metadata = model.transcribe(wav, use_vad=not args.no_vad)
        if not raw:
            raise RuntimeError('No speech returned from ASR; file not marked complete')
        # Capture raw ASR text before any script conversion; no old SRT is used.
        raw_text = '\n'.join(f'{s["start"]:.3f}-{s["end"]:.3f}\t{s["text"]}' for s in raw)
        converted = romanize_segments(raw, method=args.romanizer,
                                      ollama_model=args.ollama_model,
                                      cache_dir=args.output / 'romanization_cache')
        cues = captionize(converted)
        flags = checks_for_asr(converted, cues)
        # Write complete outputs atomically. Mark completion LAST.
        print(f'[{eid}] 4/4: saving SRT, raw speech and QA metadata...', flush=True)
        transcript = {
            'episode': eid, 'video_id': row['video_id'], 'youtube_url': video_url,
            'created_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
            'profile': profile(args), 'asr_metadata': metadata,
            'note': 'Unverified ASR candidate. Romanization is not audio verification.',
            'segments': converted, 'subtitle_cues': cues, 'review_flags': flags,
        }
        write_text_atomic(out['txt'], raw_text + '\n')
        write_text_atomic(out['json'], json.dumps(transcript, ensure_ascii=False, indent=2) + '\n')
        write_text_atomic(out['srt'], srt_format(cues))
        write_text_atomic(out['done.json'], json.dumps({
            'signature': signature, 'episode': eid, 'youtube_video_id': row['video_id'],
            'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
            'num_asr_segments': len(raw), 'num_srt_cues': len(cues),
            'num_review_flags': len(flags)
        }, indent=2) + '\n')
        return len(cues), len(flags), video_url
    finally:
        if args.keep_temp:
            print(f'[{eid}] Diagnostic temp files retained: {working}', file=sys.stderr)
        else:
            shutil.rmtree(working, ignore_errors=True)
            print(f'[{eid}] deleted temporary media/WAV.', flush=True)


def status_rows(output, manifest, episode_ids, sig):
    rows = []
    for n in episode_ids:
        eid = episode_id(n)
        p = paths(output, eid)
        if p['srt'].exists() and p['done.json'].exists():
            try:
                saved = json.loads(p['done.json'].read_text(encoding='utf-8'))
                status = 'complete' if saved.get('signature') == sig else 'different_config'
                cues = saved.get('num_srt_cues','')
                flags = saved.get('num_review_flags','')
            except Exception:
                status, cues, flags = 'incomplete', '', ''
        else:
            status, cues, flags = ('incomplete' if p['srt'].exists() or p['done.json'].exists() else 'pending'), '', ''
        rows.append({'episode': eid, 'status': status, 'cues': cues, 'review_flags': flags,
                     'url': manifest[n]['url']})
    return rows


def write_status(output, manifest, selected, sig):
    rows = status_rows(output, manifest, selected, sig)
    write_csv(output / 'status.csv', rows, ['episode','status','cues','review_flags','url'])
    return rows


def main(args=None, backend_factory=None, runner=process_one):
    args = args if args is not None else cli()
    manifest = read_manifest(args.manifest)
    selected = select_episodes(args.episodes, manifest)
    sig = fingerprint(profile(args))
    rows = status_rows(args.output, manifest, selected, sig)
    print(f'Manifest: {len(manifest)} episodes; selected {len(selected)}; profile {sig[:12]}.')
    if args.dry_run or args.status:
        for r in rows:
            print(f'{r["episode"]}: {r["status"]} -> {r["url"]}')
        if args.status:
            print('Status:', {k:sum(r['status']==k for r in rows) for k in set(r['status'] for r in rows)})
        return 0
    args.output.mkdir(parents=True, exist_ok=True)
    tmpbase = args.temp_dir or args.output / '_temporary_media'
    tmpbase.mkdir(parents=True, exist_ok=True)
    # Avoid two simultaneous processes deleting each other's temp files.
    lock = args.output / '.run.lock'
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        raise RuntimeError(f'Another run may be active: {lock}. Remove lock ONLY when no job is running.')
    with os.fdopen(fd, 'w') as f:
        f.write(f'pid={os.getpid()} started={dt.datetime.now(dt.timezone.utc).isoformat()}\n')
    errors = []
    try:
        # Abandoned own-work-dir cleanup is safe only after owning the global lock.
        for old in tmpbase.glob('asr_episode_*'):
            if old.is_dir():
                shutil.rmtree(old)
        preflight(args)
        # Initialize once at the first PENDING episode (not on fully resumed runs).
        from roman_asr.models import make_backend
        factory = backend_factory or make_backend
        model = None
        for index, n in enumerate(selected, 1):
            row = manifest[n]
            eid = row['episode']
            print(f'\n===== [{index}/{len(selected)}] {eid} =====', flush=True)
            try:
                if completed(args.output, eid, sig, force=args.force):
                    print(f'{eid}: already done; skipping', flush=True)
                    continue
                if model is None:
                    print('Initializing ASR backend (model weights are cached across episodes)...', flush=True)
                    model = factory(args.model, device=args.device, compute=args.compute, language=args.language)
                count, flagged, url = runner(row, args, model, sig)
                print(f'{eid}: saved {count} cues; {flagged} automatic review flags.', flush=True)
            except KeyboardInterrupt:
                raise
            except Exception as exc:
                errors.append({'episode':eid, 'error':f'{type(exc).__name__}: {exc}', 'url':row['url']})
                print(f'FAILED {eid}: {exc}', file=sys.stderr, flush=True)
                if not args.keep_going:
                    raise
            finally:
                write_status(args.output, manifest, selected, sig)
            if args.sleep > 0 and index < len(selected):
                time.sleep(args.sleep)
        if errors:
            write_csv(args.output / 'errors.csv', errors, ['episode','error','url'])
        completed_count = sum(r['status']=='complete' for r in write_status(args.output, manifest, selected, sig))
        print(f'\nDONE: {completed_count}/{len(selected)} episode(s) complete. '
              f'SRTs: {args.output/"srt"}; flags in transcripts/*.json; status.csv')
        return 0 if not errors else 2
    finally:
        lock.unlink(missing_ok=True)

if __name__ == '__main__':
    sys.exit(main())
