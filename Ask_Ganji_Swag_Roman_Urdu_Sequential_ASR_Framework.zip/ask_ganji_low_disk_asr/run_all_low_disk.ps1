$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
python run.py --episodes all --download-mode audio --model roman-small --romanizer uroman --device auto --keep-going
python report.py
