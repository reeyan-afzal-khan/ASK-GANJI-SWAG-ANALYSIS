#!/usr/bin/env python3
"""Make one CSV of transcript review flags and an episode quality summary."""
import argparse, json
from pathlib import Path
from roman_asr.core import read_manifest, write_csv

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'run_output')
    p.add_argument('--manifest',type=Path,default=Path(__file__).resolve().parent/'data/episodes.csv')
    a=p.parse_args(argv)
    by_ep=[]; flagged=[]
    manifest=read_manifest(a.manifest)
    for n,row in manifest.items():
        ep=row['episode']; file=a.output/'transcripts'/f'{ep}.json'
        if not file.exists():continue
        x=json.loads(file.read_text(encoding='utf-8'))
        segs=x.get('segments',[]); cues=x.get('subtitle_cues',[])
        script=sum(any('\u0600'<=ch<='\u06FF' for ch in s.get('text','')) for s in segs)
        approx=sum(c.get('timing_method')=='approximate_proportional' for c in cues)
        for flag in x.get('review_flags',[]):
            flagged.append({'episode':ep,'reason':flag['reasons'],'start':flag['start'],
                'end':flag['end'],'text':flag['text'],
                'youtube_timestamp':f"{row['url']}&t={int(flag['start'])}s"})
        by_ep.append({'episode':ep,'asr_segments':len(segs),'srt_cues':len(cues),
                      'original_urdu_script_segments':sum('asr_original_text' in s for s in segs),
                      'remaining_urdu_script_segments':script,
                      'approximate_timing_cues':approx,
                      'flags':len(x.get('review_flags',[])),
                      'youtube_url':row['url']})
    write_csv(a.output/'review_flags.csv',flagged,
        ['episode','reason','start','end','text','youtube_timestamp'])
    write_csv(a.output/'quality_summary.csv',by_ep,
        ['episode','asr_segments','srt_cues','original_urdu_script_segments',
         'remaining_urdu_script_segments','approximate_timing_cues','flags','youtube_url'])
    print(f"Processed reports for {len(by_ep)} episodes; {len(flagged)} review flags.")
if __name__=='__main__':main()
