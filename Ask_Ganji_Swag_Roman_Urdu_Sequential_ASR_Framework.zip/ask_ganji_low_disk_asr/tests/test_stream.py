import csv
import json
import tempfile
import unittest
import wave
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import run
from roman_asr.core import read_manifest, parse_srt
from roman_asr.romanize import romanize

class SmallBackend:
    called = 0
    def transcribe(self, wav, use_vad=True):
        SmallBackend.called += 1
        with wave.open(str(wav)) as w:
            assert w.getframerate() == 16000
            assert w.getnchannels() == 1
        return [dict(start=.1,end=1.0,text='Aaj hum machine learning discuss karenge',
                     avg_logprob=-.3,compression_ratio=1.1,no_speech_prob=0.1)], {'mock':True}

class LowDiskTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory()
        self.root=Path(self.t.name)
        self.manifest=self.root/'episodes.csv'
        self.manifest.write_text('episode,video_id,url\nepisode_001,n6YzJOh2Fvo,https://www.youtube.com/watch?v=n6YzJOh2Fvo\n', encoding='utf-8')
        self.args=SimpleNamespace(episodes='all',manifest=self.manifest,
            output=self.root/'out',temp_dir=None,download_mode='audio',model='roman-small',
            romanizer='none',ollama_model='qwen3:1.7b',language='auto',device='cpu',compute='auto',
            no_vad=False,force=False,keep_going=True,keep_temp=False,min_free_gb=0,
            sleep=0,cookies_from_browser=None,js_runtime='deno',dry_run=False,status=False)

    def tearDown(self): self.t.cleanup()

    def mock_run(self, command, **kwargs):
        # Replace network yt-dlp with local WAV. Real FFmpeg still handles conversion.
        if command[:3] == [sys.executable,'-m','yt_dlp']:
            target=Path(command[command.index('-o')+1].replace('.%(ext)s','.wav'))
            with wave.open(str(target),'wb') as w:
                w.setnchannels(1);w.setsampwidth(2);w.setframerate(16000)
                w.writeframes(b'\0\0'*16000)
            return SimpleNamespace(returncode=0)
        return self.real_subprocess_run(command, **kwargs)

    def test_success_cleanup_and_resume(self):
        import subprocess
        self.real_subprocess_run=subprocess.run
        SmallBackend.called=0
        with patch.object(run.subprocess,'run',side_effect=self.mock_run):
            result=run.main(self.args,backend_factory=lambda *a,**kw:SmallBackend())
        self.assertEqual(result,0)
        self.assertEqual(SmallBackend.called,1)
        self.assertTrue((self.args.output/'srt/episode_001.srt').exists())
        self.assertTrue((self.args.output/'transcripts/episode_001.json').exists())
        self.assertTrue((self.args.output/'raw_asr/episode_001.txt').exists())
        self.assertEqual(list((self.args.output/'_temporary_media').glob('*')),[])
        with patch.object(run.subprocess,'run',side_effect=RuntimeError('Should not re-download')):
            self.assertEqual(run.main(self.args,backend_factory=lambda *a,**kw:SmallBackend()),0)
        self.assertEqual(SmallBackend.called,1)
        self.assertEqual(len(parse_srt((self.args.output/'srt/episode_001.srt').read_text())),1)
        self.args.language='ur'
        with self.assertRaisesRegex(RuntimeError,'DIFFERENT model/config'):
            run.completed(self.args.output,'episode_001',run.fingerprint(run.profile(self.args)))

    def test_failed_job_removes_media(self):
        import subprocess
        self.real_subprocess_run=subprocess.run
        class Fails:
            def transcribe(self,*a,**kw):raise RuntimeError('mock ASR failure')
        with patch.object(run.subprocess,'run',side_effect=self.mock_run):
            result=run.main(self.args,backend_factory=lambda *a,**kw:Fails())
        self.assertEqual(result,2)
        self.assertEqual(list((self.args.output/'_temporary_media').glob('*')),[])
        self.assertFalse((self.args.output/'done/episode_001.done.json').exists())
        self.assertIn('mock ASR failure',(self.args.output/'errors.csv').read_text())

    def test_manifest_241(self):
        manifest=read_manifest(Path(run.__file__).parent/'data/episodes.csv')
        self.assertEqual(len(manifest),241)
        self.assertEqual(len(set(e['video_id'] for e in manifest.values())),241)

    def test_download_exactly_one(self):
        cmd=run.make_download_command('https://www.youtube.com/watch?v=n6YzJOh2Fvo',self.root,'audio')
        self.assertIn('--no-playlist',cmd)
        self.assertIn('bestaudio/best',cmd)
        self.assertNotIn(run.PLAYLIST,cmd)

    def test_profile_hash(self):
        self.assertEqual(run.fingerprint({'a':1,'b':2}),run.fingerprint({'b':2,'a':1}))

if __name__=='__main__':unittest.main()

class RomanizationTests(unittest.TestCase):
    def test_only_urdu_span_is_transliterated(self):
        from unittest.mock import patch
        from roman_asr.romanize import romanize
        class FakeRomanizer:
            def romanize_string(self, text, lcode):
                self._last = text
                self._lang = lcode
                return 'aaj hum'
        with patch('roman_asr.romanize._uroman_engine', return_value=FakeRomanizer()):
            self.assertEqual(romanize('آج ہم machine learning discuss کریں', method='uroman'),
                             'aaj hum machine learning discuss aaj hum')

class EvalTests(unittest.TestCase):
    def test_human_reference_wer(self):
        from roman_asr.quality import error_rates
        self.assertEqual(error_rates('Aaj hum machine learning seekhenge',
                                      'Aaj hum machine learning dekhenge')['wer'], 1/5)
