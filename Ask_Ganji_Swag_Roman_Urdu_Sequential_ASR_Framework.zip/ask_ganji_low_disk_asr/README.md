# Ask Ganji Swag — low-disk, sequential, fresh Roman Urdu + English ASR

**Your playlist:** https://www.youtube.com/playlist?list=PLinUrn8TVRE-hm3-CsyoQaySKYbxLtG6B

**Goal:** Re-transcribe the **audio** for all 241 episode videos, writing **Roman Urdu for Urdu speech and normal English spelling for English words** (code-switching). This is an actual new speech-recognition pass, NOT transliteration of the old `.srt` files. We intentionally do not include the old 241 subtitles: they are not required and contain recognized errors.

## 1. Low-disk execution order

The program does this **one episode at a time** and never fetches the next episode until the current one has finished or failed:

```
Episode 001 (fixed YouTube ID from data/episodes.csv)
       |
       v
Download ONE source media file (audio-only by default, or full video if selected)
       |
       v
FFmpeg -> 16,000-Hz, mono, 16-bit PCM temporary WAV
       |
       v
Delete the downloaded source media immediately (free space)
       |
       v
Whisper ASR from WAV -> Roman Urdu + code-switched English
       |
       v
If necessary: Romanize any Urdu-script residue (optional)
       |
       v
Write SRT + RAW ASR text + word/segment details + JSON QA + completion marker
       |
       v
DELETE the WAV and any temporary download fragments (also on ordinary failure)
       |
       v
Episode 002, ... , Episode 241
```

Download defaults to the **audio track** of the video, not the full picture, as the most storage-efficient and acoustically equivalent option for speech recognition. If you specifically need a video file downloaded first, use **`--download-mode video`**. Both paths create the requested `.wav` and delete intermediate files. For 16 kHz mono 16-bit audio, the WAV itself takes about **115 MB per hour**; at peak you need enough space for **one compressed media file + one WAV + model cache**. The models are cached between episodes (not re-downloaded 241 times). Do not delete the model cache between episodes.

## 2. Install (Python 3.10–3.12 suggested)

### Linux / Ubuntu

```bash
sudo apt-get update
sudo apt-get install -y ffmpeg
# Install Deno (>=2.3) following https://docs.deno.com/runtime/getting_started/installation/
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python run.py --episodes 2 --dry-run
```

For NVIDIA, first install a compatible CUDA-enabled PyTorch build from https://pytorch.org/get-started/locally/. The default uses GPU if available; otherwise CPU (potentially much slower). FFmpeg and Deno need to be on `PATH`.

### Windows (PowerShell)

Install Python, FFmpeg, and [Deno](https://docs.deno.com/runtime/getting_started/installation/); add FFmpeg and Deno to `PATH`.

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -U pip
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python run.py --episodes 2 --dry-run
```

**Note on YouTube as of 2026:** yt-dlp may need an external JS runtime to download from YouTube; install **Deno >=2.3**. `yt-dlp[default]` includes companion EJS scripts. If yt-dlp stops working because YouTube changes its site, update it with `pip install -U "yt-dlp[default]"`. See https://github.com/yt-dlp/yt-dlp/wiki/EJS. Only download videos you have permission to access and process; some videos may be blocked, removed, or require authenticated access.

### Where to put caches when your drive is small

The model weights persist across episodes and can require gigabytes. Put model caches on another disk, if available:

**Linux/macOS:** `export HF_HOME=/mnt/other_disk/huggingface`

**Windows PowerShell:** `$env:HF_HOME="D:\\AIModels\\huggingface"`

Temporary media storage can also be moved: `--temp-dir /mnt/scratch` (or `--temp-dir D:\Temp`). These do not change where the final SRT files are written.

## 3. Recommended pilot (genuinely new audio-based transcription)

**Run the small Roman-Urdu-fine-tuned Whisper first**, on episode 002:

```bash
python run.py --episodes 2 --model roman-small --device auto --keep-going
```

Run the five-episode pilot, then inspect outputs:

```bash
python run.py --episodes 2,35,100,113,163 --model roman-small --device auto --keep-going
python report.py
```

Only after listening to a sample and deciding that this ASR model is adequate should you launch the full run. **Neither model has verified low WER on this specific playlist.** Roman Small's subtitle timing is **approximate**, because it uses VAD windows rather than a reliable Roman Urdu word aligner. The JSON and QA report expose this, rather than concealing it.

## 4. Run ALL 241 episodes sequentially (the command you need)

**Storage-efficient audio source** (recommended):

```bash
python run.py --episodes all --download-mode audio --model roman-small \
  --romanizer uroman --device auto --keep-going
```

**Download one actual video file first, then convert that to WAV**, as in your exact requested order:

```bash
python run.py --episodes all --download-mode video --model roman-small \
  --romanizer uroman --device auto --keep-going
```

The `uroman` option is used **only for leftover Urdu-script text** after direct Roman Urdu ASR. It is a crude transliterator, not a perfect Roman Urdu writer; **existing English words are left unchanged**. Some speech, names, and English terms require listening and corrections.

### Stronger comparison: Whisper Turbo + local language-preserving romanization

Whisper Turbo may understand some speech better than fine-tuned Small but commonly writes Urdu in the Urdu script. You can use **local Ollama** (extra runtime and storage) to Romanize only the recognized text:

```bash
# Install Ollama separately from https://ollama.com/ and start its local service.
ollama pull qwen3:1.7b

python run.py --episodes 2 --model turbo-urdu --language ur \
  --romanizer ollama --ollama-model qwen3:1.7b \
  --output run_output_turbo --keep-going
```

The Ollama step can accidentally paraphrase. The framework saves **raw ASR text** separately, flags altered segments, and never treats Ollama as an independent audio judge. For longer runs, local LLM conversion may become a major time bottleneck. Another approach is `--model turbo-roman-prompt --romanizer uroman`, but prompts cannot guarantee Roman script or accuracy. Do **not** point two different model configurations at the same output directory unless you intentionally use `--force`.

## 5. Resuming after interruptions

Simply repeat the **identical** command. Finished episodes with matching settings are skipped; failed or missing episodes are retried. Outputs are saved after each episode, **before** the next download. To target only some: `--episodes 25-50` or `--episodes 2,35,100`.

```bash
python run.py --status
python run.py --episodes 25-50 --model roman-small --keep-going
python report.py
```

`--status` reports completed/pending/different-configuration episodes. A completion marker is written only after SRT, JSON and raw audio-text output are saved. `--force` allows replacing existing completed files if deliberately rerunning. The runner uses a `.run.lock` file to prevent concurrent runs; if the process is force-killed and leaves that lock, remove it **only after confirming no instance is running**. Stale scratch media are cleaned at the start of the next run once the lock is acquired. `--keep-temp` is intended only for debugging and **will use additional disk space**.

### Download/access failures

`--keep-going` logs errors in `run_output/errors.csv` and moves to the next video. No cookies or bypasses are bundled. For videos you are permitted to access that require a browser session, an optional `--cookies-from-browser chrome` (or `firefox`) option is available. YouTube may restrict yt-dlp, and an unavailable recording cannot be reconstructed from its SRT.

## 6. Outputs (small, permanent files only)

```
run_output/
├── srt/
│   ├── episode_001.srt
│   └── ... episode_241.srt
├── raw_asr/
│   └── episode_001.txt        <- Whisper's recognition BEFORE Romanization
├── transcripts/
│   └── episode_001.json       <- segment times, raw originals on converted segments, flags
├── done/
│   └── episode_001.done.json  <- signed completion marker (resume guard)
├── _temporary_media/         <- EMPTY after each episode
├── status.csv
├── errors.csv                 <- only if errors occurred
├── quality_summary.csv       <- generated by report.py
├── review_flags.csv          <- generated by report.py, timestamped YouTube links
└── romanization_cache/       <- only converted text, small; reused on resume
```

`data/episodes.csv` includes **241 unique YouTube video IDs**, extracted from your previously shared repository/question index, preserving original `episode_001`–`episode_241` naming. The `inspect_playlist.py` utility can report any playlist additions/removals without silently changing those IDs. It does **not** download every video.

## 7. Assess actual correctness (manual reference required)

Structural flags and model diagnostic scores are NOT calibrated probabilities of correctness. For real transcription accuracy, open a few YouTube intervals, listen, and manually type what was said. Copy `examples/references_template.csv` to e.g. `references.csv`, fill the `reference` column with literal Roman Urdu + English, then:

```bash
python evaluate.py --references references.csv
python report.py
```

This computes a spelling-sensitive WER/CER comparison against *manually transcribed* clips, not the old Whisper SRTs. Times are in seconds, and output is `run_output/evaluation.csv`. With long ASR segments overlapping your reference boundaries the simple time-window comparison may include extra words, so pick clip boundaries near sentence/segment breaks and inspect examples manually. Roman Urdu spellings are variable; a consistent style makes WER more meaningful.

## 8. Limitations (important)

- **Accuracy:** model may still miss English/Urdu switch points, hallucinate words, or phonetic-spell English. You should review flagship portions before replacing public subtitles.
- **Timestamp fidelity:** Small VAD captions use proportional timing; Turbo's word alignment is estimated; Romanization can make even Turbo's subtitle timings proportional again. The JSON indicates provenance.
- **Video size:** `--download-mode video` is bigger than audio-only. Only one source + one WAV are stored at a time; the **largest single episode** determines peak temporary disk demand.
- **Crash during power loss:** ordinary Python failures and Ctrl+C clean temporary files; an abrupt OS kill leaves temp media until the next run clears it. No program can guarantee cleanup after sudden power loss.
- **Model storage:** persistent downloaded weights, software environments, and generated transcripts also use disk space; only per-episode media are deleted.
- **Network:** this package was tested with a simulated local media download and actual FFmpeg conversion, **not** with live YouTube download or full pretrained ASR inference in this environment. Use the included tests and 1-episode pilot on your GPU machine.

**Source projects:** [yt-dlp](https://github.com/yt-dlp/yt-dlp), [faster-whisper](https://github.com/SYSTRAN/faster-whisper), [Whisper Turbo](https://huggingface.co/openai/whisper-large-v3-turbo), [Roman Urdu Whisper Small](https://huggingface.co/cheetos18/whisper-small-roman-urdu), [Silero VAD](https://github.com/snakers4/silero-vad).
