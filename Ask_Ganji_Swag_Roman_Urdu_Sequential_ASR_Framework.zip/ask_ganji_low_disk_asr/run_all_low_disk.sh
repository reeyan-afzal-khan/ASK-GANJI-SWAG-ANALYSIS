#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python run.py --episodes all --download-mode audio --model roman-small --romanizer uroman --device auto --keep-going
python report.py
