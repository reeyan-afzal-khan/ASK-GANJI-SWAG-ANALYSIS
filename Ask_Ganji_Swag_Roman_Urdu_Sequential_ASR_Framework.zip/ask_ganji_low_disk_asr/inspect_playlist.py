#!/usr/bin/env python3
"""Optional playlist reconciliation; keeps stable 001-241 episode-to-video mapping unchanged."""
import csv, json, subprocess, sys
from pathlib import Path
from roman_asr.core import read_manifest
from run import PLAYLIST
p=Path(__file__).resolve().parent
manifest=read_manifest(p/'data/episodes.csv')
print('Checking playlist only; episode numbering will NOT be modified.')
output=subprocess.check_output([sys.executable,'-m','yt_dlp','--flat-playlist','--dump-single-json',PLAYLIST],text=True)
obj=json.loads(output)
ids={entry.get('id') for entry in obj.get('entries',[]) if entry}
ours={r['video_id'] for r in manifest.values()}
new=ids-ours; absent=ours-ids
print(f'Playlist currently returned {len(ids)} videos; manifest contains {len(ours)}.')
print(f'New/unmapped playlist IDs ({len(new)}): {sorted(new)}')
print(f'Manifest IDs not currently in playlist ({len(absent)}): {sorted(absent)}')
print('The original episode mapping is retained. Add verified extra episodes manually to data/episodes.csv.')
